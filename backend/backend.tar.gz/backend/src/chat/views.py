# Import
import json, logging, random
from time import sleep
from django.conf import settings
from channels.generic.websocket import AsyncWebsocketConsumer
from langchain_google_genai import GoogleGenerativeAI
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

# Logger
logger = logging.getLogger(__name__)

# Class
class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        """Accepts the WebSocket connection and initializes the LLM model."""
        self.user_id = self.scope['url_route']['kwargs']['user_id']
        self.review_id = self.scope['url_route']['kwargs']['review_id']
        self.room_group_name = f'chat_{self.user_id}_{self.review_id}'

        # Add the channel to the group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )

        await self.accept()

        # self.llm = GoogleGenerativeAI(
        #     model="gemini-1.5-flash", 
        #     google_api_key=settings.GEMINI_API_KEY
        # )

        self.llm = ChatOpenAI(
            model="gpt-3.5-turbo-0125",
            api_key=settings.OPENAI_API_KEY
        )

        self.prompt = ChatPromptTemplate.from_messages([
            ("system", "You are a helpful assistant."),
            ("user", "{input}")
        ])

        self.output_parser = StrOutputParser()

    async def disconnect(self, close_code):
        """Handles WebSocket disconnection."""
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )
        logger.info(f"[WebSocket Closed] Code: {close_code}")

    async def receive(self, text_data):
        """Handles incoming messages and streams LLM responses."""
        try:
            # Parse user message
            text_data_json = json.loads(text_data)
            message = text_data_json.get("message", "").strip()
            logger.info(f"[User Message] {message}")

            if not message:
                await self.send(json.dumps({"error": "Empty message received"}))
                return

            # Create LLM processing chain
            chain = (
                self.prompt |
                self.llm.with_config({"run_name": "model"}) |
                self.output_parser.with_config({"run_name": "Assistant"})
            )

            # Stream response
            await self.streaming_response(chain, message)

        except json.JSONDecodeError:
            await self.send(json.dumps({"error": "Invalid JSON format"}))
            
        except Exception as e:
            print(f"[Error] {e}")
            await self.send(json.dumps({"error": "An error occurred while processing your request"}))

    async def streaming_response(self, chain, message):
        response_text = ""
        async for chunk in chain.astream_events(
            {"input": message}, version="v1", include_names=["Assistant"]
        ):
            if chunk["event"] in ["on_parser_start", "on_parser_stream", "on_parser_end"]:
                await self.send(json.dumps(chunk))
                response_text += chunk.get("data", "").get("chunk", "")
                # print(f"[LLM Response] {chunk}")
        logger.info(f"[LLM Response] {response_text}")