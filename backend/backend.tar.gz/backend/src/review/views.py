# Import
import logging, os, traceback, json, shutil
from rest_framework.views import APIView
from django.http import JsonResponse
from django.conf import settings
from django.utils.timezone import now
from rest_framework import status
from rest_framework.permissions import IsAuthenticated

# Import Django utility
from .models import Review, MasterPromptConfig
from .serializers import StudySerializer, StudyCardSerializer, InferenceReview
from .utils import *
from max.llm_screen_single_prompt import ScreeningAPI

from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
# logger
logger = logging.getLogger(__name__)


# StudyListAPIView Class
class StudyListAPIView(APIView):
    # # Permission
    # permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            # Query all data from the Review table
            study_obj = Review.objects.all().order_by('id')

            # Serialize the data
            serializer = StudySerializer(study_obj, many=True)

            # Message
            msg = f"Got Review list of user({request.user.id})"
            # msg = f"Got Review list of user"

            # Return the serialized data as a response
            logger.info(msg)
            return JsonResponse(
                data={"message": msg, "data": serializer.data}, status=status.HTTP_200_OK
            )

        except Exception as error:
            logger.error(f"Couldn't get dataset list for user({request.user.id}): {error}\n{traceback.format_exc()}")
            # logger.error(f"Couldn't get dataset list for user: {error}\n{traceback.format_exc()}")
            return JsonResponse(
                {"error": str(error)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class StudyCardView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """
        Get studies for document cards on screening UI
        """
        try:
            # Extract parameters from request
            review_id = request.data.get('review_id')
            page_index = int(request.data.get('page_index'))

            # Validate required parameters
            if not all([review_id, page_index is not None]):
                raise ValueError("Missing required parameters: 'review_id' or 'page_index'")

            # Get review object
            review_obj = Review.objects.get(id=review_id, user=request.user)

            # Get studies from screening_pages
            screening_pages = review_obj.screening_pages
            try:
                page_studies = screening_pages["pages"][page_index]["studies"]
            except (KeyError, IndexError, TypeError):
                raise ValueError(f"Invalid page_index({page_index}) or no studies found")

            # Serialize studies
            serializer = StudyCardSerializer(page_studies, many=True)

            msg = f"Successfully retrieved studies for review({review_id}) page({page_index})"
            logger.info(msg)

            return JsonResponse(
                data={
                    "message": msg,
                    "data": {
                        "studies": serializer.data,
                        "total_pages": len(screening_pages["pages"]),
                        "current_page": page_index
                    }
                },
                status=status.HTTP_200_OK
            )

        except Review.DoesNotExist:
            msg = f"Review({review_id}) not found"
            logger.error(msg)
            return JsonResponse(
                {"error": msg},
                status=status.HTTP_404_NOT_FOUND
            )

        except ValueError as error:
            logger.error(f"Validation error: {error}")
            return JsonResponse(
                {"error": str(error)},
                status=status.HTTP_400_BAD_REQUEST
            )

        except Exception as error:
            logger.error(f"Error retrieving studies: {error}\n{traceback.format_exc()}")
            return JsonResponse(
                {"error": "Failed to retrieve studies"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class GetStudyByIdView(APIView):
    # Uncomment the following line if authentication is required
    # permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            # Extract data from the POST request
            pmid = request.data.get('pmid', None)
            project_field = request.data.get('project_field', None)

            # Validate inputs
            if not pmid or not project_field:
                raise ValueError("Both 'id' and 'project' fields are required.")

            if project_field not in ["ask_ai_response", "detailed_reasoning", "pico_extraction"]:
                raise ValueError(f"Invalid project field '{project_field}'.")

            # Query the Review model by ID
            try:
                study_obj = Review.objects.get(id=int(pmid))
            except Review.DoesNotExist:
                msg = f"Review with ID {pmid} not found."
                logger.error(msg)
                return JsonResponse({"error": msg}, status=status.HTTP_404_NOT_FOUND)

            # Serialize the Review data with project_field passed in the context
            serializer = InferenceReview(study_obj, context={'project_field': project_field})

            if serializer is None:
                raise ValueError(f"The project field '{project_field}' does not exist in the Review.")

            msg = f"Got review dataset ({study_obj.id}) of user ({request.user.id}) with process '{project_field}'."
            logger.info(msg)
            return JsonResponse(data={"message": msg, "data": serializer.data}, status=status.HTTP_200_OK)

        except ValueError as ve:
            logger.error(f"Validation Error: {str(ve)}")
            return JsonResponse({"error": str(ve)}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            logger.error(f"Unexpected Error: {str(e)}")
            return JsonResponse({"error": "An unexpected error occurred."},
                                status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class FileUploadView(APIView):
    # Permission
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """
        Handle file upload.
            @body       nbib_file       File        A .nbib file
            @return     JsonResponse    Success message including the created corpus object
        """
        try:
            # Upload file
            nbib_file = request.FILES.get("nbib_file", None)
            corpus_obj = None

            # Format user id
            format_user_id = f"u{request.user.id:0{5}d}"

            # Create user's directory
            creat_user_dir(user=request.user, format_user_id=format_user_id)

            # Clean user temp folder (clear temp files after 24 hr.)
            clear_temp_folder(user=request.user, format_user_id=format_user_id)

            # Validate .nbib file & check duplicated in temp
            validate_upload_file(format_user_id=format_user_id, nbib_file=nbib_file)

            # Create new Corpus
            corpus_obj = Corpus.objects.create(user=request.user, status="active")
            format_corpus_id = f"c{corpus_obj.id:0{5}d}"

            # Save file into database and local storage
            path_to_temp_file, save_corpus_filename, upload_folder = save_temp_file(
                user=request.user,
                format_user_id=format_user_id,
                format_corpus_id=format_corpus_id,
                nbib_file=nbib_file
            )

            # logger
            logger.info(
                f"User({request.user}) successfully uploaded nbib file ({nbib_file.name}) to temporarily folder.")

            # Call Max's function
            if settings.BYPASS_EXTERNAL_SERVICE:
                # Save file to corpus folder (move from temp)
                parse_corpus(corpus_nbib_path=path_to_temp_file, corpus_file=save_corpus_filename)

                # Hash corpus path
                hash_corpus = hash_blake2s_32digit(key=str(request.user.id), value=save_corpus_filename)

                # Preview corpus
                preview = preview_corpus(path_to_temp_file, 1)[0]

                # Save path file into database
                corpus_obj.hash_corpus_path = hash_corpus
                corpus_obj.real_corpus_path = save_corpus_filename
                corpus_obj.corpus_first_entry = preview
                corpus_obj.save()

                # Validate unique pmid in uploaded file
                validate_unique_pmid(corpus_path=save_corpus_filename)

                # Successful message
                msg = f"Successfully insert corpus({corpus_obj.id}) into database."
                logger.info(msg)

                # Move file from temp
                shutil.move(path_to_temp_file, upload_folder)
                logger.info(f"Move file('{path_to_temp_file}') from temp to {upload_folder}.")

                # Create corpus for tevatron
                pmids = corpus_converter(corpus_path=save_corpus_filename)

                # Save corpus for tevatron into database
                corpus_obj.pmids = pmids
                corpus_obj.save()

            # Returning data
            data = {
                "preview_uploaded_corpus": {"id": corpus_obj.id, "corpus_first_entry": preview},
                "total_documents": len(pmids)
            }

            # Return
            return JsonResponse(
                data={"message": msg, "data": data},
                status=status.HTTP_200_OK
            )

        # Exception ValueError
        except ValueError as error:
            # Update corpus status
            if corpus_obj:
                corpus_obj.status = "upload_failed"
                corpus_obj.save()

            # logger
            logger.error(f"user({request.user}) failed to upload nbib file: {error}")
            return JsonResponse(
                {"error": f"user({request.user}) failed to upload nbib file: {error}"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Exception FileExistsError
        except FileExistsError as error:
            # Update corpus status
            if corpus_obj:
                corpus_obj.status = "upload_failed"
                corpus_obj.save()

            # logger
            logger.error(f"user({request.user}) failed to upload nbib file: {error}")
            return JsonResponse(
                {"error": f"user({request.user}) failed to upload nbib file: {error}"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Exception Other error
        except Exception as error:
            # Update corpus status
            if corpus_obj:
                corpus_obj.status = "upload_failed"
                corpus_obj.save()

            # logger
            logger.error(f"Error while uploading nbib file")
            return JsonResponse(
                {"error": f"Error while uploading nbib file: {error}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def delete(self, request):
        """
        Delete corpus row and its files from VM storage
            @query_param        corpus_id           Corpus ID
            @return             JsonResponse        Success message
        """
        try:
            corpus_id = request.query_params.get("corpus_id")

            # Set the corpus status to 'admin_delete'
            corpus_obj = Corpus.objects.get(id=corpus_id)
            corpus_obj.status = "admin_delete"
            corpus_obj.save()

            # User corpus directory
            user_corpus_dir = os.path.join(f"{settings.MOUNT_CORPUS_PATH}", f"u{request.user.id:0{5}d}", "corpus",
                                           f"c{corpus_obj.id:0{5}d}", "upload")

            # Delete the files from local storaage
            corpus_dir = corpus_obj.real_corpus_path

            # Delete the files from local storage
            for f in [user_corpus_dir, corpus_dir]:
                remove_file_from_local_storage(f)

            # Message
            msg = f"User({request.user.id}) has deleted corpus({corpus_id}) of user({corpus_obj.user.id})."
            logger.info(msg)
            return JsonResponse({"message": msg}, status=status.HTTP_200_OK)

        except Corpus.DoesNotExist as error:
            logger.error(
                f"corpus({corpus_id}) does not exist for user({request.user.id}): {error}"
            )
            return JsonResponse({"error": str(error)}, status=status.HTTP_404_NOT_FOUND)

        except Exception as error:
            logger.error(
                f"Couldn't delete corpus({corpus_id}) of user({request.user.id}): {error}\n{traceback.format_exc()}"
            )
            return JsonResponse(
                {"error": str(error)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class DatasetCreationView(APIView):
    # Permission
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """
        Dataset creation.
            @body       inclusion_criteria   Criteria for including studies in the review |

            @return     JsonResponse         Success message
        """
        try:
            # Data from request
            corpus_id = request.data.get('corpus_id', None)
            dataset_name = request.data.get('dataset_name', None)
            inclusion_criteria = request.data.get('inclusion_criteria', None)
            show_docs_per_page = request.data.get('show_docs_per_page', 5)
            review_obj = None

            # Query corpus
            corpus_obj = Corpus.objects.get(id=corpus_id, user=request.user)
            logger.info(f">>> real corpus path: {corpus_obj.real_corpus_path}")

            # Validated dataset name duplicate
            is_duplicated = Review.objects.filter(name=dataset_name, user=request.user)
            if is_duplicated:
                raise ValueError(f"The collection name({dataset_name}) is duplicated.")

            # Get number of queue
            n_queue = 1  # get_number_of_queue(queue_name=settings.QUEUE_NAME_1)

            # Initialize screening pages from corpus.json
            corpus_json_path = corpus_obj.real_corpus_path
            screening_pages = create_screening_pages(
                corpus_file=corpus_json_path,
                page_size=show_docs_per_page
            )

            # Create dataset
            review_obj = Review.objects.create(
                user=request.user,
                corpus=corpus_obj,
                name=dataset_name,
                screening_status="not_start",
                show_docs_per_page=show_docs_per_page,
                inclusion_criteria=inclusion_criteria,  # json fields
                pos_at_waiting_queue=n_queue,  # job
                screening_pages=screening_pages  # Add initialized screening pages
                # job_queued_at=now(),
            )
            review_obj.save()

            # Message
            msg = f"Your corpus (ID: {corpus_obj.id}) with the name '{review_obj.name}' has been created."
            logger.info(msg)

            # Return
            return JsonResponse(data={"message": msg, "data": None}, status=status.HTTP_200_OK)

        except ValueError as error:
            # Message
            msg = f"Invalid input for dataset creation: {error}"

            # Update review status
            if review_obj:
                review_obj.index_status = "indexing_error"
                review_obj.indexing_error_msg = msg

            # logging and return
            logger.error(msg)
            return JsonResponse(
                {"error": str(error)}, status=status.HTTP_400_BAD_REQUEST
            )

        except Exception as error:
            # Update review status
            if review_obj:
                review_obj.index_status = "indexing_error"
                review_obj.indexing_error_msg = str(error)

            logger.error(
                f"Couldn't create dataset for '{dataset_name}' of user({request.user.id}): {error}\n{traceback.format_exc()}"
            )
            return JsonResponse(
                {"error": str(error)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class LlmConfigView(APIView):
    # Permission
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """
        Save LLM configurations for a selected dataset.
            @body       review_id           ID of the review entry
                        pipeline_type |
                        llm_interaction_level |
            @return     JsonResponse         Success message

        """
        try:
            # Extract data from request
            review_id = request.data.get("review_id", None)
            llm_paras_str = request.data.get("llm_parameters", None)

            # Validate required fields
            if not review_id or not llm_paras_str:
                raise ValueError("Missing required fields: 'review_id' or 'llm_paras'.")

            # Parse llm_paras from JSON string
            try:
                llm_parameters = json.loads(llm_paras_str)
            except json.JSONDecodeError:
                raise ValueError("Invalid JSON format in 'llm_paras'.")

            # Fetch the existing Review entry
            review_obj = get_object_or_404(Review, id=review_id, user=request.user)

            review_obj.llm_parameters = llm_parameters
            # Extract & Save Review fields (pipeline type & AI interaction level)
            review_obj.pipeline_type = request.data.get("pipeline_type", None)
            review_obj.llm_interaction_level = request.data.get("llm_interaction_level", None)

            # Validate required fields
            if not review_obj.pipeline_type or not review_obj.llm_interaction_level:
                raise ValueError("Missing 'pipeline_type' or 'llm_interaction_level' in LLM config.")

            review_obj.save()

            # ✅ Ensure all necessary prompts exist
            loaded_prompts = MasterPromptConfig.ensure_prompts_exist(user=request.user, review=review_obj)

            # Logging success
            msg = f"LLM configuration saved successfully for review ID: {review_id}."
            if loaded_prompts:
                msg += f" Loaded prompts: {', '.join(loaded_prompts)}."

            logger.info(msg)

            # Return success response
            return JsonResponse(
                data={"message": msg, "data": None},
                status=200
            )

        except ValueError as error:
            # Logging validation error
            logger.error(f"Invalid input for LLM configuration: {error}")
            return JsonResponse(
                {"error": str(error)},
                status=400
            )

        except Exception as error:
            # General error handling
            error_msg = f"Failed to save LLM config for review ID ({review_id}): {error}\n{traceback.format_exc()}"
            logger.error(error_msg)
            return JsonResponse(
                {"error": "Internal Server Error."},
                status=500
            )


class LlmProcessView(APIView):
    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(
        operation_description="Process LLM requests for review operations",
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            required=['review_id', 'page_index', 'task'],
            properties={
                'review_id': openapi.Schema(type=openapi.TYPE_INTEGER),
                'page_index': openapi.Schema(type=openapi.TYPE_INTEGER),
                'study_index': openapi.Schema(type=openapi.TYPE_INTEGER),
                'task': openapi.Schema(
                    type=openapi.TYPE_STRING,
                    enum=['pre', 'ask_ai', 'pico_extract', 'detail_reason', 'post']
                ),
                'batch_pre': openapi.Schema(
                    type=openapi.TYPE_BOOLEAN,
                    default=False
                ),
            }
        ),
        responses={
            200: openapi.Response(
                description="Success",
                examples={
                    "application/json": {
                        "message": "Successfully processed LLM request",
                        "data": {
                            "llm_response": "Response content"
                        }
                    }
                }
            ),
            400: "Bad Request",
            404: "Not Found",
            500: "Internal Server Error"
        }
    )
    def post(self, request):
        """
        Process LLM requests for co-review operations.
            @body       review_id           ID of the review entry
                        page_index          Index of the current page
                        study_index         Index of the study in current page
                        task                Task type ('ask_ai', 'pico_extract', 'detail_reason)
                        batch_pre           Boolean, whether to process all studies in current page for pre-review
            @return     JsonResponse        Success message with LLM response
        """
        try:
            # Extract data from request
            review_id = request.data.get('review_id')
            page_index = int(request.data.get('page_index'))
            study_index = int(request.data.get('study_index'))
            task = request.data.get('task')
            batch_pre = request.data.get('batch_pre', False)  # Default to False

            # Validate required fields
            if not all([review_id, page_index is not None, task]):
                raise ValueError("Missing required fields")

            # Get review object and validate pipeline type
            review_obj = Review.objects.get(id=review_id, user=request.user)

            # Validate task against pipeline type
            pipeline_type = review_obj.pipeline_type
            allowed_tasks = {
                'pre-only': ['pre'],
                'co-only': ['ask_ai', 'pico_extract', 'detail_reason'],
                'post-only': ['post'],
                'pre-co': ['pre', 'ask_ai', 'pico_extract', 'detail_reason'],
                'pre-post': ['pre', 'post'],
                'co-post': ['ask_ai', 'pico_extract', 'detail_reason', 'post'],
                'full': ['pre', 'ask_ai', 'pico_extract', 'detail_reason', 'post']
            }

            if pipeline_type not in allowed_tasks:
                raise ValueError(f"Invalid pipeline type: {pipeline_type}")

            if task not in allowed_tasks[pipeline_type]:
                raise ValueError(
                    f"Task '{task}' not allowed in pipeline '{pipeline_type}'. "
                    f"Allowed tasks are: {', '.join(allowed_tasks[pipeline_type])}"
                )

            screening_pages = review_obj.screening_pages

            # Handle batch pre-processing
            if task == 'pre' and batch_pre:
                current_page = screening_pages["pages"][page_index]
                if len(current_page["studies"]) > 10:
                    raise ValueError("Batch pre-processing only available for pages with 10 or fewer studies")

                responses = []
                for idx, study in enumerate(current_page["studies"]):
                    llm_response = self._process_single_study(
                        review_obj, study, task, page_index, idx
                    )
                    # Extract content from AIMessage object
                    responses.append({
                        "study_index": idx,
                        "content": llm_response.content
                    })

                msg = f"Successfully processed pre-review for {len(responses)} studies in page {page_index}"
                return JsonResponse(
                    data={"message": msg, "data": {"llm_responses": responses}},
                    status=status.HTTP_200_OK
                )

            # Regular single study processing
            if study_index is None:
                raise ValueError("study_index is required for single study processing")

            llm_response = self._process_single_study(
                review_obj,
                screening_pages["pages"][page_index]["studies"][study_index],
                task,
                page_index,
                study_index
            )

            msg = f"Successfully processed LLM request for study in page {page_index}, position {study_index}"
            return JsonResponse(
                data={"message": msg, "data": {"llm_response": llm_response.content}},
                status=status.HTTP_200_OK
            )

        except ValueError as error:
            logger.error(f"Validation error in LLM processing: {error}")
            return JsonResponse(
                {"error": str(error)},
                status=status.HTTP_400_BAD_REQUEST
            )

        except (Review.DoesNotExist, MasterPromptConfig.DoesNotExist) as error:
            logger.error(f"Database object not found: {error}")
            return JsonResponse(
                {"error": str(error)},
                status=status.HTTP_404_NOT_FOUND
            )

        except Exception as error:
            logger.error(f"Error in LLM processing: {error}\n{traceback.format_exc()}")
            return JsonResponse(
                {"error": "Internal server error occurred during LLM processing."},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def _process_single_study(self, review_obj, study_data, task, page_index, study_index):
        """Helper method to process a single study"""
        # Validate task type
        if task not in ['pre', 'ask_ai', 'pico_extract', 'detail_reason', 'post']:
            raise ValueError(f"Invalid task type: {task}")

        # Get prompt from MasterPromptConfig
        prompt_type_map = {
            'pre': 'pre_prompt',
            'ask_ai': 'co_ask_ai_prompt',
            'pico_extract': 'co_pico_extract_prompt',
            'detail_reason': 'co_detail_reason_prompt',
            'post': 'post_prompt'
        }
        prompt_type = prompt_type_map[task]

        # For post task, verify user_feedback exists and map to Decision
        if task == 'post':
            user_feedback = study_data.get("user_feedback")
            if user_feedback is None:
                raise ValueError(
                    "Cannot generate post-review without human decision. Please provide include/exclude feedback first.")

            # Map user_feedback to Decision format expected by post prompt
            decision_map = {
                "include": "Include",
                "exclude": "Exclude"
            }
            study_data["decision"] = decision_map.get(user_feedback)
            if not study_data["decision"]:
                raise ValueError(f"Invalid user feedback value: {user_feedback}")

        # For detail_reason task, verify co_rating exists
        elif task == 'detail_reason':
            if study_data.get("co_rating") is None:
                raise ValueError(
                    "Cannot generate detailed reasoning without a prior rating. Please run 'ask_ai' first.")
            study_data["rating"] = study_data["co_rating"]

        # Get prompt config
        prompt_config = MasterPromptConfig.objects.get(
            user=review_obj.user,
            review=review_obj,
            prompt_type=prompt_type
        )

        if not prompt_config or not prompt_config.prompt_content:
            raise ValueError(f"Prompt configuration not found for type: {prompt_type}")

            # Get LLM parameters from review
        llm_params = review_obj.llm_parameters
        if not llm_params:
            raise ValueError("LLM parameters not configured for this review")

        # Format LLM config
        llm_config = {
            "model_name": llm_params["model_name"],
            "temperature": llm_params["temperature"],
            "max_tokens": llm_params["max_tokens"],
            "response_format": {"type": "text"} if llm_params["response_format"] == "text"
            else llm_params["response_format"],
            "streaming": llm_params.get("streaming", True),
            "api_key": settings.OPENAI_API_KEY
        }

        # Initialize ScreeningAPI with LLM config
        screening_api = ScreeningAPI(
            prompt_dir=os.path.join(settings.BASE_DIR, "review", "prompts"),
            llm_config=llm_config
        )

        # Get LLM response
        llm_response = screening_api.screen_study(
            study=study_data,
            role=task if task in ['pre', 'post'] else 'co',
            task='ask_ai' if task == 'pre' else task,
            inclusion_criteria=review_obj.inclusion_criteria
        )

        # Store responses based on task type
        screening_pages = review_obj.screening_pages
        if task == 'pre':
            decision = extract_pre(llm_response.content)
            if decision:
                screening_pages["pages"][page_index]["studies"][study_index]["pre_response"] = decision
        elif task == 'ask_ai':
            rating = extract_rating(llm_response.content)
            if rating is not None:
                screening_pages["pages"][page_index]["studies"][study_index]["co_rating"] = rating
        elif task == 'post':
            screening_pages["pages"][page_index]["studies"][study_index]["post_response"] = llm_response.content

        review_obj.screening_pages = screening_pages
        review_obj.save()

        return llm_response


class UserFeedbackView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """
        Store user's feedback (include/exclude) for a study.
            @body       review_id           ID of the review entry
                       page_index          Index of the current page
                       study_index         Index of the study in current page
                       feedback            User's feedback ('include' or 'exclude')
            @return     JsonResponse        Success message
        """
        try:
            # Extract data from request
            review_id = request.data.get('review_id')
            page_index = int(request.data.get('page_index'))
            study_index = int(request.data.get('study_index'))
            feedback = request.data.get('feedback')

            # Validate required fields
            if not all([review_id, page_index is not None, study_index is not None, feedback]):
                raise ValueError("Missing required fields: 'review_id', 'page_index', 'study_index', or 'feedback'")

            # Validate feedback value
            if feedback not in ['include', 'exclude']:
                raise ValueError("Feedback must be either 'include' or 'exclude'")

            # Get review object
            review_obj = Review.objects.get(id=review_id, user=request.user)
            screening_pages = review_obj.screening_pages

            # Update user feedback
            try:
                study = screening_pages["pages"][page_index]["studies"][study_index]
                study["user_feedback"] = feedback

                # Update the study in screening_pages
                screening_pages["pages"][page_index]["studies"][study_index] = study
                review_obj.screening_pages = screening_pages
                review_obj.save()

                # Update include_docs or exclude_docs lists
                pmid = study.get("pmid")
                if pmid:
                    if feedback == 'include':
                        include_docs = review_obj.include_docs or []
                        if pmid not in include_docs:
                            include_docs.append(pmid)
                            review_obj.include_docs = include_docs
                    else:  # exclude
                        exclude_docs = review_obj.exclude_docs or []
                        if pmid not in exclude_docs:
                            exclude_docs.append(pmid)
                            review_obj.exclude_docs = exclude_docs
                    review_obj.save()

                msg = f"Successfully stored user feedback for study in page {page_index}, position {study_index}"
                logger.info(msg)
                return JsonResponse(
                    data={"message": msg, "data": None},
                    status=status.HTTP_200_OK
                )

            except (IndexError, KeyError):
                raise ValueError(f"Invalid page_index({page_index}) or study_index({study_index})")

        except ValueError as error:
            logger.error(f"Validation error in storing user feedback: {error}")
            return JsonResponse(
                {"error": str(error)},
                status=status.HTTP_400_BAD_REQUEST
            )

        except Review.DoesNotExist as error:
            logger.error(f"Review not found: {error}")
            return JsonResponse(
                {"error": str(error)},
                status=status.HTTP_404_NOT_FOUND
            )

        except Exception as error:
            logger.error(f"Error in storing user feedback: {error}\n{traceback.format_exc()}")
            return JsonResponse(
                {"error": "Internal server error occurred while storing feedback."},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )








