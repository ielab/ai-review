import requests
import json


login_token="ea1cdab2d0b08c353c66151624349c789c69330f"
# Test study listing.
# reqUrl = "https://aireview.ielab.io/api/review/studies"
# post_data = {
# }

# Test file uploading.
# reqUrl = "https://aireview.ielab.io/api/review/upload_corpus"
# post_files = {
#   "nbib_file": open("./max/aireview_demo.ris", "rb"),
# }
headersList = {
  "Accept": "*/*",
  "Authorization": f"Token {login_token}"
}
#
# payload = ""
# response = requests.request("POST", reqUrl, data=payload, files=post_files, headers=headersList)

# Test dataset creation
# inclusion_criteria = json.load(open("./max/inclusion_criteria.json"))['aireview_template']
# reqUrl = "https://aireview.ielab.io/api/review/dataset_creation"
#
# post_data = {
#   "corpus_id": 4,
#   "dataset_name": "demo-full",
#   "inclusion_criteria": f"{inclusion_criteria}",
#   "show_docs_per_page": 5
# }

# Test llm config
llm_paras = json.load(open("./max/llm_paras.json"))
print(llm_paras)

reqUrl = "https://aireview.ielab.io/api/review/llm_config"
post_data = {
    "review_id": 5,
    "llm_parameters": json.dumps(llm_paras),
    "pipeline_type": "full",
    "llm_interaction_level": False,
    "ranking_method": "original",
}

# Test list studies for selected page
# reqUrl = "https://aireview.ielab.io/api/review/study_cards"
# post_data = {
#     "review_id": 5,
#     "page_index": 0,
# }

# Test co-review with low interaction level
# reqUrl = "https://aireview.ielab.io/api/review/llm_process"
# post_data = {
#     "review_id": 5,
#     "page_index": 0,
#     "study_index": 1,
#     "task": "detail_reason"
# }
# ask_ai, pico_extract, detail_reason

# post_data = {
#     "review_id": "4",
#     "page_index": 0,
#     "study_index": 1,
#     "task": "detail_reason"
# }
# ask_ai, pico_extract, detail_reason

# Test pre-review, point-wise
# post_data = {
#     "review_id": 5,
#     "page_index": 0,
#     "study_index": 1,
#     "task": "pre"
# }
# Test pre-review, batch-processing
# post_data = {
#     "review_id": 5,
#     "page_index": 0,
#     "task": "pre",
#     "study_index": 1,
#     "batch_pre": True,
# }
# Test post-review
# post_data = {
#     "review_id": 5,
#     "page_index": 0,
#     "task": "post",
#     "study_index": 1,
# }
# Test user feedback
# reqUrl = "https://aireview.ielab.io/api/review/user_feedback"
# post_data = {
#     "review_id": 5,
#     "page_index": 0,
#     "study_index": 1,
#     "feedback": "include"
# }
# "exclude"
response = requests.request("POST", reqUrl, data=post_data, headers=headersList)
response_text = json.loads(response.text)
print(response.status_code)
print(response_text)
